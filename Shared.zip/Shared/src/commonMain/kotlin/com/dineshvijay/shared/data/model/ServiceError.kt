package com.dineshvijay.shared.data.model

data class ServiceError(val code: Int,
                        val reason: String)