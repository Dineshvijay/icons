package com.dineshvijay.shared.data.repository

import com.dineshvijay.shared.data.api.TodosAPI
import com.dineshvijay.shared.data.source.network.HTTPService

class RepositoryFactory {
    companion object fun todosRepository(): TodosRepository = TodosRepository(TodosAPI(HTTPService()))
}