package com.dineshvijay.shared.data.repository

import com.dineshvijay.shared.data.api.TodosAPI
import com.dineshvijay.shared.data.model.ServiceError
import com.dineshvijay.shared.data.model.Todos

class TodosRepository(private val source: TodosAPI): TodosWebService {
    override suspend fun addItem(item: Todos): Pair<Todos?, ServiceError?> {
        return source.addTodo(item)
    }

    override suspend fun updateItem(item: Todos): Pair<Todos?, ServiceError?> {
        return source.updateTodo(item)
    }

    override suspend fun deleteItem(item: Todos): Pair<Todos?, ServiceError?> {
        return source.deleteTodo(item)
    }

    override suspend fun getItem(item: Todos): Pair<Todos?, ServiceError?> {
        return source.getTodoItem(item)
    }

    override suspend fun getAllItems(): Pair<List<Todos>?, ServiceError?> {
        return source.getAllItems()
    }
}