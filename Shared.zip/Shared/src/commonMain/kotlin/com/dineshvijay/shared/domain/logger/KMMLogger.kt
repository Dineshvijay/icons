package com.dineshvijay.shared.domain.logger

import io.ktor.client.features.logging.*

class KMMLogger: Logger {
    override fun log(message: String) {
        print("🚨 $message")
    }
}