package com.dineshvijay.shared.data.model

import io.ktor.http.cio.websocket.*
import kotlinx.serialization.Serializable

@Serializable
data class Todos(val id: Int,
                 val userId: Int,
                 val title: String,
                 val completed: Boolean)

