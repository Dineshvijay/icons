package com.dineshvijay.shared.data.source.network

import com.dineshvijay.shared.domain.logger.KMMLogger
import io.ktor.client.*
import io.ktor.client.features.json.*
import io.ktor.client.features.json.serializer.*
import io.ktor.client.features.logging.*
import io.ktor.client.statement.*

class HTTPService {
    val client = HttpClient() {
        install(JsonFeature) {
            val json = kotlinx.serialization.json.Json {
                ignoreUnknownKeys = true
                isLenient = true
                prettyPrint = true
            }
            serializer = KotlinxSerializer(json)
        }

        install(Logging) {
            logger = KMMLogger()
            level = LogLevel.ALL
        }
    }

    fun logHttpCall(response: HttpResponse, responseString: String) {
        val url = response.request.url
        val content = response.request.content
        val method = response.request.method
        val status = response.status
        val reqheaders = response.request.headers
        val resHeaders = response.headers
        val stringBody = responseString
    }
}