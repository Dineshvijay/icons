package com.dineshvijay.shared.data.api

import com.dineshvijay.shared.data.model.ServiceError
import com.dineshvijay.shared.data.model.Todos
import com.dineshvijay.shared.data.source.network.HTTPService
import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*

class TodosAPI(private val httpService: HTTPService) {

    suspend fun addTodo(item: Todos): Pair<Todos?, ServiceError?> {
        return try {
            val response: HttpResponse = httpService
                .client
                .request("https://jsonplaceholder.typicode.com/todos/${item.id}") {
                    method = HttpMethod.Post
                    contentType(ContentType.Application.Json)
                    body = item
                }
            val model = response.receive<Todos>()
            val stringBody: String = response.receive()
            httpService.logHttpCall(response, stringBody)
            Pair(model, null)
        } catch(cause: Throwable) {
            val error = ServiceError(1000, cause.toString())
            Pair(null, error)
        }
    }

    suspend fun deleteTodo(item: Todos): Pair<Todos?, ServiceError?> {
        return try {
            val response: HttpResponse = httpService
                .client
                .request("https://jsonplaceholder.typicode.com/todos/${item.id}") {
                    method = HttpMethod.Delete
                    contentType(ContentType.Application.Json)
                    body = item
                }
            val model = response.receive<Todos>()
            val stringBody: String = response.receive()
            httpService.logHttpCall(response, stringBody)
            Pair(model, null)
        } catch(cause: Throwable) {
            val error = ServiceError(1000, cause.toString())
            Pair(null, error)
        }
    }

    suspend fun updateTodo(item: Todos): Pair<Todos?, ServiceError?> {
        return try {
            val response: HttpResponse = httpService
                .client
                .request("https://jsonplaceholder.typicode.com/todos/${item.id}") {
                    method = HttpMethod.Put
                    contentType(ContentType.Application.Json)
                    body = item
                }
            val model = response.receive<Todos>()
            val stringBody: String = response.receive()
            httpService.logHttpCall(response, stringBody)
            Pair(model, null)
        } catch(cause: Throwable) {
            val error = ServiceError(1000, cause.toString())
            Pair(null, error)
        }
    }

    suspend fun getTodoItem(item: Todos): Pair<Todos?, ServiceError?> {
        return try {
            val response: HttpResponse = httpService
                .client
                .request("https://jsonplaceholder.typicode.com/todos/${item.id}") {
                method = HttpMethod.Get
                contentType(ContentType.Application.Json)
            }
            val model = response.receive<Todos>()
            val stringBody: String = response.receive()
            httpService.logHttpCall(response, stringBody)
            Pair(model, null)
        } catch(cause: Throwable) {
            val error = ServiceError(1000, cause.toString())
            Pair(null, error)
        }
    }

    suspend fun getAllItems(): Pair<List<Todos>?, ServiceError?> {
        return try {
            val response: HttpResponse = httpService.client.request("https://jsonplaceholder.typicode.com/todos") {
                method = HttpMethod.Get
                contentType(ContentType.Application.Json)
            }
            val model = response.receive<List<Todos>>()
            val stringBody: String = response.receive()
            httpService.logHttpCall(response, stringBody)
            Pair(model, null)
        } catch(cause: Throwable) {
            val error = ServiceError(1000, cause.toString())
            Pair(null, error)
        }
    }
}