package com.dineshvijay.shared.data.api

import io.ktor.client.*

internal class BlogPostAPI(private val httpClient: HttpClient) {

}