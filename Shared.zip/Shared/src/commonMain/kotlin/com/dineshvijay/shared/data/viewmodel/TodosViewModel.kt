package com.dineshvijay.shared.data.viewmodel

import com.dineshvijay.shared.data.model.Todos
import com.dineshvijay.shared.data.repository.TodosRepository
import dev.icerock.moko.mvvm.dispatcher.EventsDispatcher
import dev.icerock.moko.mvvm.livedata.LiveData
import dev.icerock.moko.mvvm.livedata.MutableLiveData
import dev.icerock.moko.mvvm.viewmodel.ViewModel
import kotlinx.coroutines.launch

class TodosViewModel(private val repository: TodosRepository,
                     val eventsDispatcher: EventsDispatcher<TodosEventsListener>): ViewModel() {

    private var todosList = MutableLiveData<List<Todos>>(listOf())
    private var _todoTitle = MutableLiveData<String>("")
    var todosTitle: LiveData<String> = _todoTitle

    fun todosListItems(): LiveData<List<Todos>> {
        return todosList
    }

    fun getTodosList() {
        viewModelScope.launch {
            val (dataList, error) = repository.getAllItems()
            processTodosList(dataList)
        }
    }

    private fun processTodosList(items: List<Todos>?) {
        if(items != null) {
            todosList.value = items
            _todoTitle.value = items.first().title
        }
    }

    fun listItemSelected() {
        eventsDispatcher.dispatchEvent { showTodoDetailPage() }
    }

    interface TodosEventsListener {
        fun showTodoDetailPage()
    }
}