package com.dineshvijay.shared.data.repository

import com.dineshvijay.shared.data.model.BlogPost
import com.dineshvijay.shared.data.model.ServiceError
import com.dineshvijay.shared.data.model.Todos

interface TodosWebService {
    suspend fun addItem(item: Todos): Pair<Todos?, ServiceError?>
    suspend fun updateItem(item: Todos): Pair<Todos?, ServiceError?>
    suspend fun deleteItem(item: Todos): Pair<Todos?, ServiceError?>
    suspend fun getItem(item: Todos): Pair<Todos?, ServiceError?>
    suspend fun getAllItems(): Pair<List<Todos>?, ServiceError?>
}

interface BlogPostWebService {
    suspend fun addItem(item: BlogPost): Pair<BlogPost?, ServiceError?>
    suspend fun updateItem(item: BlogPost): Pair<BlogPost?, ServiceError?>
    suspend fun deleteItem(item: BlogPost): Pair<BlogPost?, ServiceError?>
    suspend fun getItem(item: BlogPost): Pair<BlogPost?, ServiceError?>
    suspend fun getAllItems(): Pair<List<BlogPost>?, ServiceError?>
}