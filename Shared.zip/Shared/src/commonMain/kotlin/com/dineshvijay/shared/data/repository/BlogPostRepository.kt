package com.dineshvijay.shared.data.repository

import com.dineshvijay.shared.data.api.BlogPostAPI


internal class BlogPostRepository(private val source: BlogPostAPI) {

}