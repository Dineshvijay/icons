package com.dineshvijay.shared.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Photos(val id: Int,
                  val albumId: Int,
                  val url: String,
                  val thumbnailUrl: String)
