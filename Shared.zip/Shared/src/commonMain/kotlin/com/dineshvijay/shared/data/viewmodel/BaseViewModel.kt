package com.dineshvijay.shared.data.viewmodel

import com.dineshvijay.shared.data.repository.RepositoryFactory
import dev.icerock.moko.mvvm.viewmodel.ViewModel

open class BaseViewModel(repositoryFactory: RepositoryFactory): ViewModel() {

}