package com.dineshvijay.shared.data.api

internal class AlbumAPI {
}